#!/usr/bin/env python3
"""
经营数据分析工具 — 纯本地运行，数据不出本机
============================================
用法:  python analyze.py 数据文件.xlsx  [-o 输出报告.html]

依赖:  pip install openpyxl matplotlib
输入:  含订单明细的 Excel 文件（.xlsx）
输出:  HTML 格式经营分析报告（含图表、数据表、洞察）

数据安全: 全部在本地运算，不上传任何数据到网络。
"""

import argparse, base64, hashlib, logging, os, sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
logger = logging.getLogger("analyze")

# ── 跨平台中文字体 ──
_FONT_CANDIDATES = [
    # Linux
    "WenQuanYi Zen Hei", "Noto Sans CJK SC", "Noto Sans CJK JP",
    "Source Han Sans SC", "AR PL UMing CN",
    # macOS
    "PingFang SC", "STHeiti", "Heiti SC",
    # Windows
    "Microsoft YaHei", "SimHei", "DengXian",
]

def _setup_matplotlib():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.ticker as mticker
    from matplotlib.font_manager import FontProperties, findfont, fontManager

    # try to find a working font
    for name in _FONT_CANDIDATES:
        try:
            fp = FontProperties(family=name)
            findfont(fp, fallback_to_default=False)
            plt.rcParams["font.sans-serif"] = [name]
            break
        except Exception:
            continue
    else:
        # fallback — try to find any CJK font on system
        for f in fontManager.ttflist:
            if any(kw in (f.name or "").lower() for kw in ["cjk", "chinese", "sc", "hei", "ming", "song", "yahei", "pingfang"]):
                plt.rcParams["font.sans-serif"] = [f.name]
                break
    plt.rcParams["axes.unicode_minus"] = False
    return plt

plt = _setup_matplotlib()


# ============================================================
# 数据分析
# ============================================================

MONTHS = ["4月","5月","6月","7月","8月","9月","10月","11月","12月","1月","2月","3月"]


def load_data(excel_path: str) -> list:
    """加载 Excel 数据"""
    import openpyxl
    wb = openpyxl.load_workbook(excel_path, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()

    data = []
    for r in rows[1:]:
        gsv_str = str(r[0]).strip() if r[0] is not None else "0"
        try: gsv = float(gsv_str) if gsv_str else 0.0
        except: gsv = 0.0
        m = str(r[34]).strip() if len(r) > 34 and r[34] else "3月"
        if m.startswith("2026"): m = "3月"
        data.append({
            "gsv": gsv,
            "brand": str(r[11] or "") if len(r) > 11 else "",
            "cat3": str(r[18] or "") if len(r) > 18 else "",
            "store": str(r[13] or "") if len(r) > 13 else "",
            "prov": str(r[61] or "") if len(r) > 61 else "",
            "prod_id": str(r[8] or "") if len(r) > 8 else "",
            "order_id": str(r[2] or "") if len(r) > 2 else "",
            "month": m,
        })
    return data


def aggregate(data: list) -> dict:
    """多维度聚合"""
    result = {}
    TOTAL = sum(d["gsv"] for d in data)
    monthly = {m: {"gsv": 0.0, "orders": set()} for m in MONTHS}
    for d in data:
        monthly[d["month"]]["gsv"] += d["gsv"]
        monthly[d["month"]]["orders"].add(d["order_id"])

    cat3_total = defaultdict(float)
    brand_total = defaultdict(float)
    store_gsv = defaultdict(float)
    prov_total = defaultdict(float)
    prov_orders = defaultdict(set)
    prod_cat3 = defaultdict(set)
    month_prods = {m: set() for m in MONTHS}
    all_prods = set()

    for d in data:
        cat3_total[d["cat3"]] += d["gsv"]
        brand_total[d["brand"]] += d["gsv"]
        if d["store"]: store_gsv[d["store"]] += d["gsv"]
        if d["prov"]:
            prov_total[d["prov"]] += d["gsv"]
            prov_orders[d["prov"]].add(d["order_id"])
        if d["prod_id"]:
            prod_cat3[d["cat3"]].add(d["prod_id"])
            all_prods.add(d["prod_id"])
            month_prods[d["month"]].add(d["prod_id"])

    result["TOTAL"] = TOTAL
    result["monthly"] = monthly
    result["cat3_sorted"] = sorted(cat3_total.items(), key=lambda x: -x[1])
    result["brand_total"] = brand_total
    result["brands_sorted"] = sorted(brand_total.items(), key=lambda x: -x[1])
    result["stores_sorted"] = sorted(store_gsv.items(), key=lambda x: -x[1])
    result["prov_total"] = prov_total
    result["provs_sorted"] = sorted(prov_total.items(), key=lambda x: -x[1])
    result["prod_cat3"] = prod_cat3
    result["month_prods"] = month_prods
    result["all_prods"] = all_prods
    result["order_count"] = len(set(d["order_id"] for d in data))
    result["record_count"] = len(data)
    return result


# ============================================================
# 图表生成
# ============================================================

def generate_charts(agg: dict, work_dir: str) -> dict:
    charts = {}
    monthly, TOTAL = agg["monthly"], agg["TOTAL"]

    # 1. Monthly bar
    months_act = [m for m in MONTHS if monthly[m]["gsv"] > 0]
    vals = [monthly[m]["gsv"] / 10000 for m in months_act]
    if months_act:
        fig, ax = plt.subplots(figsize=(10, 4))
        bars = ax.bar(months_act, vals, color="#2563eb", width=0.55,
                      edgecolor="white", linewidth=0.8)
        for b, v in zip(bars, vals):
            ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.3,
                    f"{v:.1f}", ha="center", va="bottom", fontsize=10,
                    fontweight="bold", color="#1e293b")
        ax.set_ylabel("GSV（万元）", fontsize=11, color="#64748b")
        ax.set_title("月度GSV达成", fontsize=15, fontweight="bold", color="#1e293b", pad=15)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.tick_params(colors="#64748b", labelsize=10)
        ax.set_ylim(0, max(vals) * 1.18)
        charts["monthly"] = _save_chart(fig, "monthly", work_dir)

    # 2. Category donut
    cats = agg["cat3_sorted"]
    if cats:
        fig, ax = plt.subplots(figsize=(7, 5))
        labels = [f"{c}  {v / TOTAL * 100:.1f}%" for c, v in cats]
        colors_cat = ["#2563eb","#f59e0b","#10b981","#ef4444","#8b5cf6",
                      "#ec4899","#14b8a6","#f97316","#06b6d4","#84cc16"]
        ax.pie([v for _, v in cats], labels=labels,
               colors=colors_cat[:len(cats)],
               startangle=90, counterclock=False,
               wedgeprops={"edgecolor": "white", "linewidth": 2.5},
               textprops={"fontsize": 13, "color": "#1e293b"})
        ax.set_title("品类GSV占比", fontsize=16, fontweight="bold", color="#1e293b", pad=15)
        charts["category"] = _save_chart(fig, "category", work_dir)

    # 3. Brand horizontal bar (top 10)
    brands10 = agg["brands_sorted"][:10]
    if brands10:
        names_b = [b for b, _ in brands10[::-1]]
        vals_b = [v / 10000 for _, v in brands10[::-1]]
        fig, ax = plt.subplots(figsize=(9, 5))
        bars = ax.barh(names_b, vals_b, color="#2563eb", height=0.5, edgecolor="white", linewidth=0.5)
        for b, v in zip(bars, vals_b):
            ax.text(b.get_width() + 0.15, b.get_y() + b.get_height() / 2,
                    f"{v:.1f}万", ha="left", va="center", fontsize=10, color="#64748b")
        ax.set_xlabel("GSV（万元）", fontsize=11, color="#64748b")
        ax.set_title("品牌GSV TOP10", fontsize=15, fontweight="bold", color="#1e293b", pad=15)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.tick_params(colors="#64748b", labelsize=10)
        ax.set_xlim(0, max(vals_b) * 1.35)
        charts["brand"] = _save_chart(fig, "brand", work_dir)

    # 4. Store bar (top 10)
    stores10 = agg["stores_sorted"][:10]
    if stores10:
        names_s = [s[:10] + "…" if len(s) > 10 else s for s, _ in stores10[::-1]]
        vals_s = [v / 10000 for _, v in stores10[::-1]]
        fig, ax = plt.subplots(figsize=(9, 5))
        bars = ax.barh(names_s, vals_s, color="#10b981", height=0.5, edgecolor="white")
        for b, v in zip(bars, vals_s):
            ax.text(b.get_width() + 0.1, b.get_y() + b.get_height() / 2,
                    f"{v:.1f}万", ha="left", va="center", fontsize=9, color="#64748b")
        ax.set_xlabel("GSV（万元）", fontsize=11, color="#64748b")
        ax.set_title("商家GSV TOP10", fontsize=15, fontweight="bold", color="#1e293b", pad=15)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.tick_params(colors="#64748b", labelsize=9)
        ax.set_xlim(0, max(vals_s) * 1.35)
        charts["store"] = _save_chart(fig, "store", work_dir)

    # 5. Province bar
    provs10 = agg["provs_sorted"][:10]
    if provs10:
        names_p = [p for p, _ in provs10]
        vals_p = [v / 10000 for _, v in provs10]
        colors_p = ["#2563eb","#3b82f6","#60a5fa","#93c5fd","#bfdbfe",
                    "#1d4ed8","#1e40af","#3730a3","#312e81","#1e1b4b"]
        fig, ax = plt.subplots(figsize=(10, 4.5))
        bars = ax.bar(names_p, vals_p, color=colors_p[:len(provs10)], width=0.55, edgecolor="white")
        for b, v in zip(bars, vals_p):
            ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.2,
                    f"{v:.1f}", ha="center", va="bottom", fontsize=9,
                    color="#1e293b", fontweight="bold")
        ax.set_ylabel("GSV（万元）", fontsize=11, color="#64748b")
        ax.set_title("区域GSV TOP10", fontsize=15, fontweight="bold", color="#1e293b", pad=15)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.tick_params(colors="#64748b", labelsize=9)
        plt.setp(ax.get_xticklabels(), rotation=30, ha="right", fontsize=9)
        ax.set_ylim(0, max(vals_p) * 1.2)
        charts["province"] = _save_chart(fig, "province", work_dir)

    return charts


def _save_chart(fig, name, work_dir):
    path = os.path.join(work_dir, f"{name}.png")
    fig.savefig(path, dpi=180, bbox_inches="tight", facecolor="white", edgecolor="none")
    plt.close(fig)
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    return f"data:image/png;base64,{b64}"


# ============================================================
# HTML 报告生成
# ============================================================

def build_html(agg: dict, charts: dict, title: str, now: str) -> str:
    TOTAL = agg["TOTAL"]
    cats = agg["cat3_sorted"]
    brands_sorted = agg["brands_sorted"]
    stores_sorted = agg["stores_sorted"]
    provs_sorted = agg["provs_sorted"]
    monthly = agg["monthly"]
    brand_total = agg["brand_total"]

    gsv_wan = TOTAL / 10000
    active_3 = len(agg["month_prods"]["3月"])
    all_prods = agg["all_prods"]
    top3_stores = stores_sorted[:3]
    top3_stores_gsv = sum(v for _, v in top3_stores)

    def _cat3_rows():
        rows = ""
        for i, (c, v) in enumerate(cats):
            bg = "#F8FAFC" if i % 2 == 0 else "#FFFFFF"
            rows += f"""<tr style="background:{bg}">
                <td style="padding:8px 12px;font-size:13px">{c}</td>
                <td style="padding:8px 12px;font-size:13px;text-align:right;font-weight:600">{v:,.0f}</td>
                <td style="padding:8px 12px;font-size:13px;text-align:right">
                    <div style="display:flex;align-items:center;gap:8px;justify-content:flex-end">
                        <div style="width:80px;height:6px;background:#E2E8F0;border-radius:3px;overflow:hidden">
                            <div style="width:{v/TOTAL*100}%;height:100%;background:#2563eb;border-radius:3px"></div>
                        </div>
                        <span style="color:#64748B">{v/TOTAL*100:.1f}%</span>
                    </div>
                </td>
            </tr>"""
        return rows

    def _brand_rows():
        rows = ""
        for i, (b, v) in enumerate(brands_sorted[:15]):
            bg = "#F8FAFC" if i % 2 == 0 else "#FFFFFF"
            rows += f"""<tr style="background:{bg}">
                <td style="padding:6px 10px;font-size:12px">{b}</td>
                <td style="padding:6px 10px;font-size:12px;text-align:right">{v:,.0f}</td>
                <td style="padding:6px 10px;font-size:12px;text-align:right">{v/TOTAL*100:.1f}%</td>
            </tr>"""
        return rows

    def _store_rows():
        rows = ""
        for i, (s, v) in enumerate(stores_sorted[:15]):
            bg = "#F8FAFC" if i % 2 == 0 else "#FFFFFF"
            so = int(v / max(s[1] for s in stores_sorted[:1]) * 100) if stores_sorted else 0  # placeholder
            rows += f"""<tr style="background:{bg}">
                <td style="padding:6px 10px;font-size:12px">{s}</td>
                <td style="padding:6px 10px;font-size:12px;text-align:right">{v:,.0f}</td>
                <td style="padding:6px 10px;font-size:12px;text-align:right">—</td>
            </tr>"""
        return rows

    def _prov_rows():
        rows = ""
        for i, (p, v) in enumerate(provs_sorted):
            bg = "#F8FAFC" if i % 2 == 0 else "#FFFFFF"
            rows += f"""<tr style="background:{bg}">
                <td style="padding:6px 10px;font-size:12px">{p}</td>
                <td style="padding:6px 10px;font-size:12px;text-align:right">{v:,.0f}</td>
                <td style="padding:6px 10px;font-size:12px;text-align:right">{v/TOTAL*100:.1f}%</td>
            </tr>"""
        return rows

    def _prod_rows():
        rows = ""
        prod_cat3 = agg["prod_cat3"]
        for c, _ in cats:
            pa = len(prod_cat3[c] & agg["month_prods"]["3月"])
            pt = len(prod_cat3[c])
            if pa == 0: continue
            rate = pa / pt if pt > 0 else 0
            rows += f"""<tr>
                <td style="padding:8px 12px;font-size:13px">{c}</td>
                <td style="padding:8px 12px;font-size:13px;text-align:right;font-weight:600">{pa}</td>
                <td style="padding:8px 12px;font-size:13px;text-align:right">{pt}</td>
                <td style="padding:8px 12px;font-size:13px;text-align:right">
                    <div style="display:flex;align-items:center;gap:8px;justify-content:flex-end">
                        <div style="width:60px;height:6px;background:#E2E8F0;border-radius:3px;overflow:hidden">
                            <div style="width:{rate*100}%;height:100%;background:#10b981;border-radius:3px"></div>
                        </div>
                        <span style="color:#64748B">{rate:.1%}</span>
                    </div>
                </td>
            </tr>"""
        return rows

    lenovo_total = brand_total.get("联想", 0) + brand_total.get("联想百应", 0)
    third_party = sum(brand_total.get(b, 0) for b in ["华硕", "戴尔", "惠普"])
    cat_pct1 = cats[0][1] / TOTAL * 100 if cats else 0

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
  *,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Noto Sans SC","PingFang SC","Microsoft YaHei",sans-serif;background:#F1F5F9;color:#1E293B;line-height:1.6}}
  .header{{background:linear-gradient(135deg,#0F172A 0%,#1E293B 100%);color:#fff;padding:40px 0 36px;border-bottom:4px solid #2563EB}}
  .header .inner{{max-width:1100px;margin:0 auto;padding:0 32px}}
  .header h1{{font-size:26px;font-weight:700;margin-bottom:4px}}
  .header .sub{{color:#94A3B8;font-size:14px}}
  .header .meta{{color:#64748B;font-size:12px;margin-top:10px;display:flex;gap:20px}}
  .kpi-bar{{max-width:1100px;margin:-24px auto 0;padding:0 32px;display:grid;grid-template-columns:repeat(4,1fr);gap:14px;position:relative;z-index:10}}
  .kpi-card{{background:#fff;border-radius:10px;padding:18px 22px;box-shadow:0 1px 3px rgba(0,0,0,.06);border-top:3px solid #2563EB}}
  .kpi-card:nth-child(2){{border-top-color:#10B981}}
  .kpi-card:nth-child(3){{border-top-color:#F59E0B}}
  .kpi-card:nth-child(4){{border-top-color:#8B5CF6}}
  .kpi-card .label{{font-size:11px;color:#64748B;margin-bottom:3px}}
  .kpi-card .value{{font-size:24px;font-weight:700;color:#1E293B}}
  .kpi-card .unit{{font-size:12px;color:#94A3B8;font-weight:400;margin-left:2px}}
  .container{{max-width:1100px;margin:0 auto;padding:0 32px}}
  .section{{margin-top:28px}}
  .section-title{{font-size:17px;font-weight:700;color:#1E293B;padding-bottom:8px;border-bottom:2px solid #E2E8F0;margin-bottom:16px;display:flex;align-items:center;gap:10px}}
  .section-title .badge{{font-size:10px;font-weight:500;padding:2px 10px;border-radius:20px;background:#DBEAFE;color:#2563EB}}
  .card-grid{{display:grid;gap:18px}}
  .card-grid.two{{grid-template-columns:1fr 1fr}}
  .card{{background:#fff;border-radius:10px;box-shadow:0 1px 3px rgba(0,0,0,.05);overflow:hidden}}
  .card .body{{padding:18px}}
  .card .ctitle{{font-size:13px;font-weight:600;color:#64748B;margin-bottom:12px;letter-spacing:.02em}}
  .card img{{width:100%;height:auto;display:block}}
  .data-table{{width:100%;border-collapse:collapse}}
  .data-table th{{background:#1E293B;color:#fff;font-size:11px;font-weight:600;padding:8px 10px;text-align:left;white-space:nowrap}}
  .data-table th.r{{text-align:right}}
  .data-table tr:hover{{background:#F1F5F9!important}}
  .full-card{{background:#fff;border-radius:10px;box-shadow:0 1px 3px rgba(0,0,0,.05);padding:22px}}
  .insight{{background:#EFF6FF;border-left:4px solid #2563EB;border-radius:0 8px 8px 0;padding:12px 16px;margin-top:14px;font-size:13px;color:#1E40AF;line-height:1.7}}
  .insight.green{{background:#F0FDF4;border-left-color:#10B981;color:#166534}}
  .insight.purple{{background:#FAF5FF;border-left-color:#8B5CF6;color:#5B21B6}}
  .footer{{text-align:center;padding:28px;color:#94A3B8;font-size:11px;margin-top:36px;border-top:1px solid #E2E8F0}}
  @media(max-width:768px){{.kpi-bar{{grid-template-columns:1fr 1fr}}.card-grid.two{{grid-template-columns:1fr}}}}
</style></head>
<body>
<div class="header">
  <div class="inner">
    <h1>📊 经营分析报告</h1>
    <div class="sub">{title}</div>
    <div class="meta">
      <span>📅 {now}</span>
      <span>🔬 纯本地运算 · 数据不存留</span>
    </div>
  </div>
</div>

<div class="kpi-bar">
  <div class="kpi-card"><div class="label">GSV（总成交额）</div><div class="value">{gsv_wan:.0f}<span class="unit">万元</span></div></div>
  <div class="kpi-card"><div class="label">订单量</div><div class="value">{agg["order_count"]}<span class="unit">单</span></div></div>
  <div class="kpi-card"><div class="label">动销商品</div><div class="value">{active_3}<span class="unit">个</span></div></div>
  <div class="kpi-card"><div class="label">活跃品牌</div><div class="value">{len(brand_total)}<span class="unit">个</span></div></div>
</div>

<div class="container">
  <div class="section">
    <div class="section-title">📈 整体达成 <span class="badge">月度快照</span></div>
    <div class="card"><div class="body"><img src="{charts.get("monthly","")}" alt="月度GSV"></div></div>
    <div class="insight"><strong>3月GSV达成{gsv_wan:.0f}万</strong>，订单量{agg["order_count"]}单，动销商品{active_3}个（上架{len(all_prods)}个），整体动销率{active_3/len(all_prods)*100:.1f}%。</div>
  </div>

  <div class="section">
    <div class="section-title">📦 品类维度 <span class="badge">{len(cats)}个品类</span></div>
    <div class="card-grid two">
      <div class="card"><div class="body"><img src="{charts.get("category","")}" alt="品类占比"></div></div>
      <div class="card"><div class="body"><div class="ctitle">品类GSV明细</div>
      <table class="data-table"><thead><tr><th>品类</th><th class="r">GSV</th><th class="r">占比</th></tr></thead><tbody>{_cat3_rows()}</tbody></table></div></div>
    </div>
    <div class="insight"><strong>核心发现：</strong>Top1 {cats[0][0]} 占比{cat_pct1:.1f}%。</div>
  </div>

  <div class="section">
    <div class="section-title">🏷️ 品牌维度 <span class="badge">{len(brand_total)}个品牌</span></div>
    <div class="card-grid two">
      <div class="card"><div class="body"><img src="{charts.get("brand","")}" alt="品牌TOP10"></div></div>
      <div class="card"><div class="body"><div class="ctitle">品牌GSV TOP15</div>
      <table class="data-table"><thead><tr><th>品牌</th><th class="r">GSV</th><th class="r">占比</th></tr></thead><tbody>{_brand_rows()}</tbody></table></div></div>
    </div>
    <div class="insight green"><strong>品牌洞察：</strong>联想系（含联想百应）占比{lenovo_total/TOTAL*100:.1f}%；第三方品牌（华硕/戴尔/惠普）合计占比{third_party/TOTAL*100:.1f}%。</div>
  </div>

  <div class="section">
    <div class="section-title">🛒 商品维度 <span class="badge">动销率 {active_3/len(all_prods)*100:.1f}%</span></div>
    <div class="full-card">
      <div style="font-size:13px;color:#64748B;margin-bottom:10px">3月动销 <strong>{active_3}</strong>个 / 上架 <strong>{len(all_prods)}</strong>个</div>
      <table class="data-table"><thead><tr><th>品类</th><th class="r">动销数</th><th class="r">上架数</th><th class="r">动销率</th></tr></thead><tbody>{_prod_rows()}</tbody></table>
    </div>
  </div>

  <div class="section">
    <div class="section-title">🏪 商家维度 <span class="badge">{len(stores_sorted)}家店铺</span></div>
    <div class="card-grid two">
      <div class="card"><div class="body"><img src="{charts.get("store","")}" alt="商家TOP10"></div></div>
      <div class="card"><div class="body"><div class="ctitle">商家GSV TOP15</div>
      <table class="data-table"><thead><tr><th>店铺</th><th class="r">GSV</th><th class="r">占比</th></tr></thead><tbody>{_store_rows()}</tbody></table></div></div>
    </div>
    <div class="insight purple"><strong>商家格局：</strong>Top3 合计GSV {top3_stores_gsv:,.0f}，占比{top3_stores_gsv/TOTAL*100:.1f}%。</div>
  </div>

  <div class="section">
    <div class="section-title">📍 区域维度 <span class="badge">{len(provs_sorted)}个省份</span></div>
    <div class="card-grid two">
      <div class="card"><div class="body"><img src="{charts.get("province","")}" alt="区域TOP10"></div></div>
      <div class="card"><div class="body"><div class="ctitle">区域GSV明细</div>
      <table class="data-table"><thead><tr><th>省份</th><th class="r">GSV</th><th class="r">占比</th></tr></thead><tbody>{_prov_rows()}</tbody></table></div></div>
    </div>
  </div>
</div>

<div class="footer">
  <p>🔒 本报告由本地分析工具生成，原始数据未离开您的计算机</p>
  <p style="margin-top:4px">生成时间: {now} · 数据条数: {agg["record_count"]} 条</p>
</div>
</body></html>"""


# ============================================================
# 主入口
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="📊 经营数据分析工具 — 纯本地运行，数据不出本机",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python analyze.py 订单数据.xlsx
  python analyze.py 订单数据.xlsx -o 我的报告.html
  python analyze.py 订单数据.xlsx --title "2026年3月经营分析"
        """,
    )
    parser.add_argument("input", help="订单明细Excel文件路径 (.xlsx)")
    parser.add_argument("-o", "--output", help="输出HTML报告路径（默认: 经营分析报告.html）")
    parser.add_argument("--title", default="经营分析报告", help="报告标题")
    parser.add_argument("--quiet", action="store_true", help="静默模式，仅输出报告路径")
    args = parser.parse_args()

    if args.quiet:
        logger.setLevel(logging.WARNING)

    # 验证输入文件
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"❌ 文件不存在: {args.input}")
        sys.exit(1)
    if input_path.suffix.lower() not in (".xlsx", ".xls", ".csv"):
        print(f"❌ 不支持的文件格式: {input_path.suffix}（支持 .xlsx / .xls / .csv）")
        sys.exit(1)

    output_path = args.output or "经营分析报告.html"
    now = datetime.now().strftime("%Y年%m月%d日 %H:%M")

    logger.info(f"📂 加载数据: {input_path.name}")
    data = load_data(str(input_path))
    logger.info(f"✅ 加载 {len(data)} 条记录")

    logger.info("🔍 聚合分析...")
    agg = aggregate(data)
    gsv_wan = agg["TOTAL"] / 10000
    logger.info(f"   GSV: {gsv_wan:.0f}万 | 品类: {len(agg['cat3_sorted'])} | 品牌: {len(agg['brand_total'])}")

    logger.info("📊 生成图表...")
    work_dir = Path(output_path).parent or Path(".")
    charts = generate_charts(agg, str(work_dir))

    logger.info("📝 生成HTML报告...")
    html = build_html(agg, charts, args.title, now)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"\n✅ 分析完成！报告已保存: {os.path.abspath(output_path)}")
    print(f"   数据条数: {agg['record_count']}")
    print(f"   GSV: {gsv_wan:.0f}万元")
    print(f"   打开方式: 在浏览器中打开 {output_path}")


if __name__ == "__main__":
    main()
